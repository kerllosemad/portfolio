/*
  ============================================================
  DATA FILE — this is the only file you need to touch
  to add new work, skills, or experience.
  ============================================================

  HOW TO ADD A NEW PROJECT:
  Copy one of the objects inside PROJECTS below, paste it
  as a new entry, and change the values. That's it — it will
  show up on the site automatically, filtered under its category.

  category must be exactly "web" or "design".

  image (optional): put a picture inside an "images" folder
  next to index.html, then set image: "images/yourfile.jpg".
  If you leave image empty (""), a placeholder tile with the
  project initials is shown instead — so you can publish now
  and add real screenshots later.
*/

const PROJECTS = [
  {
    title: "Add your first project here",
    category: "web", // "web" or "design"
    year: "2026",
    description: "Short 1–2 sentence description of what you built or designed and for who.",
    tags: ["HTML", "CSS", "JavaScript"],
    link: "", // project URL, or leave empty
    image: "" // "images/project1.jpg" or leave empty for placeholder
  },
  {
    title: "Add your second project here",
    category: "design",
    year: "2026",
    description: "Short description — e.g. brand identity, social media kit, poster series.",
    tags: ["Branding", "Illustrator"],
    link: "",
    image: ""
  }
];

const SKILLS = {
  technical: [
    "HTML / CSS / JavaScript",
    "Responsive Web Design",
    "Adobe Photoshop",
    "Adobe Illustrator",
    "Figma",
    "Git & GitHub"
  ],
  personal: [
    "Communication",
    "Time Management",
    "Problem Solving",
    "Attention to Detail"
  ]
};

const EXPERIENCE = [
  {
    title: "Graphic Designer",
    place: "Freelance",
    period: "Add dates",
    description: "Designed brand identities, social media kits, and print-ready visuals for clients across different industries — turning a rough idea or a one-line brief into something a client was proud to put their name on."
  },
  {
    title: "Web Developer",
    place: "Freelance",
    period: "Add dates",
    description: "Built responsive websites from scratch and from design files — handling everything from layout and styling to making sure the site actually works well on a phone, not just a laptop screen."
  }
];

const SERVICES = [
  {
    title: "Web Development",
    description: "I build fast, responsive websites that work as well on a phone as they do on a desktop — from a landing page to a full multi-section site, clean code with no unnecessary bloat."
  },
  {
    title: "Graphic Design",
    description: "Brand identities, social media kits, posters, and print-ready designs — visuals built to actually get noticed, not just fill space."
  }
];

const PROFILE = {
  name: "Kerllos Emad Zaki Atallah",
  role: "Graphic Designer & Web Developer",
  tagline: "I design the identity, then build the site that carries it. Scroll down and see for yourself.",
  bio: "I work at the point where design and code meet — from brand identities and social kits to fully responsive websites. Freelance means every project is judged on the result, so that's exactly what I focus on: work that looks sharp and holds up. Below is a mix of design and development work, updated as I finish new projects.",
  email: "your.email@example.com",
  github: "https://github.com/your-username",
  linkedin: "https://linkedin.com/in/your-username",
  location: "Egypt"
};
